package Ventanas;

public class Paciente {

	private String folio;
	private String nombre;
	private String edad;
	private String sexo;
	private String ocupacion;
	private String gradoEstudios;
	private String domicilio;
	private String estadoCivil;
	private String motivoConsulta;
	private String mes;
	private String anio;

	// Funcion constructora que crea un objeto Paciente con todos sus datos.
	public Paciente(String folioDato, String nombreDato, String edadDato, String sexoDato, String ocupacionDato,
			String gradoDato, String domicilioDato, String estadoDato, String motivoDato, String mesDato,
			String anioDato) {
		folio = folioDato;
		nombre = nombreDato;
		edad = edadDato;
		sexo = sexoDato;
		ocupacion = ocupacionDato;
		gradoEstudios = gradoDato;
		domicilio = domicilioDato;
		estadoCivil = estadoDato;
		motivoConsulta = motivoDato;
		mes = mesDato;
		anio = anioDato;
	}

	// Funcion que devuelve el folio del paciente.
	public String getFolio() {
		return folio;
	}

	// Funcion que cambia el folio del paciente.
	public void setFolio(String folioDato) {
		folio = folioDato;
	}

	// Funcion que devuelve el nombre del paciente.
	public String getNombre() {
		return nombre;
	}

	// Funcion que cambia el nombre del paciente.
	public void setNombre(String nombreDato) {
		nombre = nombreDato;
	}

	// Funcion que devuelve la edad del paciente.
	public String getEdad() {
		return edad;
	}

	// Funcion que cambia la edad del paciente.
	public void setEdad(String edadDato) {
		edad = edadDato;
	}

	// Funcion que devuelve el sexo del paciente.
	public String getSexo() {
		return sexo;
	}

	// Funcion que cambia el sexo del paciente.
	public void setSexo(String sexoDato) {
		sexo = sexoDato;
	}

	// Funcion que devuelve la ocupacion del paciente.
	public String getOcupacion() {
		return ocupacion;
	}

	// Funcion que cambia la ocupacion del paciente.
	public void setOcupacion(String ocupacionDato) {
		ocupacion = ocupacionDato;
	}

	// Funcion que devuelve el grado de estudios del paciente.
	public String getGradoEstudios() {
		return gradoEstudios;
	}

	// Funcion que cambia el grado de estudios del paciente.
	public void setGradoEstudios(String gradoDato) {
		gradoEstudios = gradoDato;
	}

	// Funcion que devuelve el domicilio del paciente.
	public String getDomicilio() {
		return domicilio;
	}

	// Funcion que cambia el domicilio del paciente.
	public void setDomicilio(String domicilioDato) {
		domicilio = domicilioDato;
	}

	// Funcion que devuelve el estado civil del paciente.
	public String getEstadoCivil() {
		return estadoCivil;
	}

	// Funcion que cambia el estado civil del paciente.
	public void setEstadoCivil(String estadoDato) {
		estadoCivil = estadoDato;
	}

	// Funcion que devuelve el motivo de consulta del paciente.
	public String getMotivoConsulta() {
		return motivoConsulta;
	}

	// Funcion que cambia el motivo de consulta del paciente.
	public void setMotivoConsulta(String motivoDato) {
		motivoConsulta = motivoDato;
	}

	// Funcion que devuelve el mes del expediente.
	public String getMes() {
		return mes;
	}

	// Funcion que cambia el mes del expediente.
	public void setMes(String mesDato) {
		mes = mesDato;
	}

	// Funcion que devuelve el año del expediente.
	public String getAnio() {
		return anio;
	}

	// Funcion que cambia el año del expediente.
	public void setAnio(String anioDato) {
		anio = anioDato;
	}

	// Funcion que verifica si el paciente pertenece al mes y año indicados.
	public boolean perteneceAlMes(String mesBuscar, String anioBuscar) {
		return mes.equals(mesBuscar) && anio.equals(anioBuscar);
	}

	// Funcion que forma el texto que se guardara en el archivo.
	public String formatoArchivo() {
		return "Folio : " + folio + "\n" + "Nombre : " + nombre + "\n" + "Edad de la persona : " + edad + "\n"
				+ "Sexo : " + sexo + "\n" + "Ocupacion de la persona : " + ocupacion + "\n"
				+ "Grado de Estudios : " + gradoEstudios + "\n" + "Domicilio : " + domicilio + "\n"
				+ "Estado Civil : " + estadoCivil + "\n" + "Motivo de consulta : " + motivoConsulta + "\n"
				+ "Mes : " + mes + "\n" + "Año : " + anio + "\n" + "--------------------";
	}

	// Funcion que forma el texto que se mostrara al usuario.
	public String formatoVista() {
		return formatoArchivo() + "\n";
	}

	// Funcion que obtiene el valor escrito despues de los dos puntos.
	public static String obtenerValor(String linea) {
		int posicion = linea.indexOf(":");
		if (posicion >= 0) {
			return linea.substring(posicion + 1).trim();
		}
		return "";
	}

	// Funcion que crea un objeto Paciente desde las lineas leidas del archivo.
	public static Paciente desdeLineas(String[] lineas, int totalLineas, String folioAsignado) {
		int posicion = 0;
		String folioDato = folioAsignado;
		if (totalLineas == 11) {
			folioDato = obtenerValor(lineas[0]);
			posicion = 1;
		}
		return new Paciente(folioDato, obtenerValor(lineas[posicion]), obtenerValor(lineas[posicion + 1]),
				obtenerValor(lineas[posicion + 2]), obtenerValor(lineas[posicion + 3]),
				obtenerValor(lineas[posicion + 4]), obtenerValor(lineas[posicion + 5]),
				obtenerValor(lineas[posicion + 6]), obtenerValor(lineas[posicion + 7]),
				obtenerValor(lineas[posicion + 8]), obtenerValor(lineas[posicion + 9]));
	}
}
