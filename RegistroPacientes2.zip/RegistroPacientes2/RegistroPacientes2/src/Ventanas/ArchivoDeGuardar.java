package Ventanas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ArchivoDeGuardar {

	private static final int MAXIMO_PACIENTES_POR_MES = 30;
	File archivo = new File("Expediente.txt");
	FileWriter accesoEscribir;
	PrintWriter escribeLine;

	// Funcion que crea el archivo de texto si todavia no existe.
	private void asegurarArchivo() {
		if (!archivo.exists()) {
			try {
				archivo.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// Funcion que guarda un paciente nuevo usando objetos y valida el limite mensual.
	public String guardarPaciente(Paciente pacienteNuevo) {
		asegurarArchivo();
		Paciente[] pacientes = leerPacientes();
		int cantidadMes = contarPacientesPorMes(pacientes, pacienteNuevo.getMes(), pacienteNuevo.getAnio());

		if (cantidadMes >= MAXIMO_PACIENTES_POR_MES) {
			return "No se puede guardar. Ya existen 30 pacientes en el mes " + pacienteNuevo.getMes() + " del año "
					+ pacienteNuevo.getAnio() + ".";
		}

		pacienteNuevo.setFolio(generarFolio(pacientes, pacienteNuevo.getMes(), pacienteNuevo.getAnio()));
		guardarArchivo(pacienteNuevo);
		return "Paciente guardado.\nFolio asignado: " + pacienteNuevo.getFolio();
	}

	// Funcion anterior adaptada para recibir datos y crear un objeto Paciente.
	public String crearArchivo(String Nombre, String Edad, String Sexo, String Ocupacion, String Gradodeestudios,
			String Domicilio, String Estadocivil, String Motivodeconsulta, String Mes, String Anio) {
		Paciente pacienteNuevo = new Paciente("", Nombre, Edad, Sexo, Ocupacion, Gradodeestudios, Domicilio,
				Estadocivil, Motivodeconsulta, Mes, Anio);
		return guardarPaciente(pacienteNuevo);
	}

	// Funcion que escribe un paciente al final del archivo de texto.
	private void guardarArchivo(Paciente pacienteNuevo) {
		if (archivo.exists()) {
			try {
				accesoEscribir = new FileWriter(archivo, true);
				escribeLine = new PrintWriter(accesoEscribir);
				escribeLine.println(pacienteNuevo.formatoArchivo());
				escribeLine.close();
				accesoEscribir.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// Funcion que busca expedientes por edad.
	public String filtrarPorEdad(String EdadBuscar) {
		return buscarExpediente("Edad de la persona", EdadBuscar);
	}

	// Funcion que busca expedientes por sexo.
	public String filtrarPorSexo(String SexoBuscar) {
		return buscarExpediente("Sexo", SexoBuscar);
	}

	// Funcion que muestra expedientes por mes.
	public String mostrarPorMes(String MesBuscar) {
		return buscarExpediente("Mes", MesBuscar);
	}

	// Funcion que muestra expedientes por año.
	public String mostrarPorAnio(String AnioBuscar) {
		return buscarExpediente("Año", AnioBuscar);
	}

	// Funcion que muestra todos los expedientes guardados en el archivo.
	public String mostrarTodos() {
		Paciente[] pacientes = leerPacientes();
		String resultado = "";

		if (pacientes.length == 0) {
			return "No hay expedientes guardados.";
		}

		for (int i = 0; i < pacientes.length; i++) {
			resultado = resultado + pacientes[i].formatoVista();
		}

		return resultado;
	}

	// Funcion que localiza un paciente usando su folio.
	public Paciente buscarPorFolio(String folioBuscar) {
		Paciente[] pacientes = leerPacientes();
		for (int i = 0; i < pacientes.length; i++) {
			if (pacientes[i].getFolio().equalsIgnoreCase(folioBuscar)) {
				return pacientes[i];
			}
		}
		return null;
	}

	// Funcion que modifica los datos de un expediente identificado por folio.
	public String modificarPaciente(Paciente pacienteModificado) {
		Paciente[] pacientes = leerPacientes();
		boolean encontrado = false;
		int cantidadMes = 0;

		for (int i = 0; i < pacientes.length; i++) {
			if (pacientes[i].perteneceAlMes(pacienteModificado.getMes(), pacienteModificado.getAnio())
					&& !pacientes[i].getFolio().equalsIgnoreCase(pacienteModificado.getFolio())) {
				cantidadMes++;
			}
		}

		if (cantidadMes >= MAXIMO_PACIENTES_POR_MES) {
			return "No se puede modificar. El mes indicado ya tiene 30 pacientes.";
		}

		for (int i = 0; i < pacientes.length; i++) {
			if (pacientes[i].getFolio().equalsIgnoreCase(pacienteModificado.getFolio())) {
				pacientes[i] = pacienteModificado;
				encontrado = true;
			}
		}

		if (encontrado) {
			reescribirArchivo(pacientes);
			return "Expediente modificado correctamente.";
		}

		return "No se encontro un expediente con ese folio.";
	}

	// Funcion que elimina un expediente identificado por folio.
	public String eliminarPaciente(String folioEliminar) {
		Paciente[] pacientes = leerPacientes();
		Paciente[] pacientesActualizados = new Paciente[pacientes.length];
		int cantidad = 0;
		boolean eliminado = false;

		for (int i = 0; i < pacientes.length; i++) {
			if (pacientes[i].getFolio().equalsIgnoreCase(folioEliminar)) {
				eliminado = true;
			} else {
				pacientesActualizados[cantidad] = pacientes[i];
				cantidad++;
			}
		}

		if (eliminado) {
			reescribirArchivo(recortarPacientes(pacientesActualizados, cantidad));
			return "Expediente eliminado correctamente.";
		}

		return "No se encontro un expediente con ese folio.";
	}

	// Funcion que busca expedientes comparando un campo del objeto Paciente.
	private String buscarExpediente(String campoBuscar, String datoBuscar) {
		Paciente[] pacientes = leerPacientes();
		String resultado = "";
		boolean encontrado = false;

		for (int i = 0; i < pacientes.length; i++) {
			if (coincideCampo(pacientes[i], campoBuscar, datoBuscar)) {
				resultado = resultado + pacientes[i].formatoVista();
				encontrado = true;
			}
		}

		if (pacientes.length == 0) {
			return "No hay expedientes guardados.";
		}

		if (encontrado == false) {
			resultado = "No se encontraron expedientes.";
		}

		return resultado;
	}

	// Funcion que compara el campo solicitado con el dato ingresado por el usuario.
	private boolean coincideCampo(Paciente paciente, String campoBuscar, String datoBuscar) {
		if (campoBuscar.equals("Edad de la persona")) {
			return paciente.getEdad().equalsIgnoreCase(datoBuscar);
		}
		if (campoBuscar.equals("Sexo")) {
			return paciente.getSexo().equalsIgnoreCase(datoBuscar);
		}
		if (campoBuscar.equals("Mes")) {
			return paciente.getMes().equalsIgnoreCase(datoBuscar);
		}
		if (campoBuscar.equals("Año")) {
			return paciente.getAnio().equalsIgnoreCase(datoBuscar);
		}
		return false;
	}

	// Funcion que lee el archivo y convierte cada registro en un objeto Paciente.
	private Paciente[] leerPacientes() {
		if (!archivo.exists()) {
			return new Paciente[0];
		}

		Paciente[] pacientes = new Paciente[1000];
		int cantidad = 0;

		try {
			FileReader accesoLeer = new FileReader(archivo);
			BufferedReader leeLinea = new BufferedReader(accesoLeer);
			String linea;
			String[] registro = new String[11];
			int totalLineas = 0;

			while ((linea = leeLinea.readLine()) != null) {
				if (linea.equals("--------------------")) {
					if (totalLineas == 10 || totalLineas == 11) {
						pacientes[cantidad] = Paciente.desdeLineas(registro, totalLineas, "SIN-FOLIO-" + (cantidad + 1));
						cantidad++;
					}
					registro = new String[11];
					totalLineas = 0;
				} else if (totalLineas < registro.length) {
					registro[totalLineas] = normalizarLinea(linea);
					totalLineas++;
				}
			}

			leeLinea.close();
			accesoLeer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return recortarPacientes(pacientes, cantidad);
	}

	// Funcion que corrige etiquetas antiguas del archivo para que puedan leerse.
	private String normalizarLinea(String linea) {
		if (linea.startsWith("Anio") || linea.startsWith("Año") || linea.startsWith("AÃ±o")) {
			int posicion = linea.indexOf(":");
			if (posicion >= 0) {
				return "Año : " + Paciente.obtenerValor(linea);
			}
		}
		return linea;
	}

	// Funcion que cuenta cuantos pacientes existen en un mes y año.
	private int contarPacientesPorMes(Paciente[] pacientes, String mesBuscar, String anioBuscar) {
		int cantidad = 0;
		for (int i = 0; i < pacientes.length; i++) {
			if (pacientes[i].perteneceAlMes(mesBuscar, anioBuscar)) {
				cantidad++;
			}
		}
		return cantidad;
	}

	// Funcion que genera un folio automatico usando año, mes y numero consecutivo.
	private String generarFolio(Paciente[] pacientes, String mesDato, String anioDato) {
		int consecutivoMayor = 0;
		String prefijo = "F-" + anioDato + mesDato + "-";

		for (int i = 0; i < pacientes.length; i++) {
			if (pacientes[i].getFolio().startsWith(prefijo)) {
				try {
					int numero = Integer.parseInt(pacientes[i].getFolio().substring(prefijo.length()));
					if (numero > consecutivoMayor) {
						consecutivoMayor = numero;
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				}
			}
		}

		return prefijo + String.format("%03d", consecutivoMayor + 1);
	}

	// Funcion que reescribe todos los pacientes en el archivo.
	private void reescribirArchivo(Paciente[] pacientes) {
		asegurarArchivo();
		try {
			accesoEscribir = new FileWriter(archivo, false);
			escribeLine = new PrintWriter(accesoEscribir);
			for (int i = 0; i < pacientes.length; i++) {
				escribeLine.println(pacientes[i].formatoArchivo());
			}
			escribeLine.close();
			accesoEscribir.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Funcion que ajusta el arreglo para dejar solo los pacientes usados.
	private Paciente[] recortarPacientes(Paciente[] pacientes, int cantidad) {
		Paciente[] pacientesRecortados = new Paciente[cantidad];
		for (int i = 0; i < cantidad; i++) {
			pacientesRecortados[i] = pacientes[i];
		}
		return pacientesRecortados;
	}
}
