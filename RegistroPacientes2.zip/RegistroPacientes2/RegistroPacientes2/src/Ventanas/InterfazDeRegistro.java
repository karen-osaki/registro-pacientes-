package Ventanas;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class InterfazDeRegistro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TxtNombre;
	private JTextField TxtEdad;
	private JTextField TxtOcupacion;
	private JTextField TxtDomicilio;
	private JTextField TxtEstadoCivil;
	private JTextField TxtMes;
	private JTextField TxtAnio;
	private JComboBox<String> ComboBoxSexo;
	private JComboBox<String> comboMotivo;
	private JTextArea textMotivo;

	// Funcion principal que inicia el programa con programacion orientada a objetos.
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			// Funcion que muestra la ventana principal del sistema.
			public void run() {
				try {
					InterfazDeRegistro frame = new InterfazDeRegistro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// Funcion constructora que crea la ventana y todos sus componentes.
	public InterfazDeRegistro() {
		setBackground(new Color(255, 198, 226));
		setTitle("Expediente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 663, 533);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 193, 224));
		panel.setOpaque(false);
		panel.setBounds(0, 21, 655, 473);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel IbIExpedientes = new JLabel("     Expedientes");
		IbIExpedientes.setBounds(193, 11, 190, 36);
		IbIExpedientes.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		panel.add(IbIExpedientes);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblNombre.setBounds(10, 75, 80, 15);
		panel.add(lblNombre);

		TxtNombre = new JTextField();
		TxtNombre.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtNombre.setBounds(106, 72, 141, 20);
		panel.add(TxtNombre);
		TxtNombre.setColumns(10);

		JLabel lblEdad = new JLabel("Edad:");
		lblEdad.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblEdad.setBounds(10, 101, 80, 15);
		panel.add(lblEdad);

		TxtEdad = new JTextField();
		TxtEdad.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtEdad.setBounds(106, 98, 141, 20);
		panel.add(TxtEdad);
		TxtEdad.setColumns(10);

		JLabel lblSexo = new JLabel("Sexo:");
		lblSexo.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblSexo.setBounds(10, 127, 80, 15);
		panel.add(lblSexo);

		ComboBoxSexo = new JComboBox<String>();
		ComboBoxSexo.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		ComboBoxSexo.addItem("");
		ComboBoxSexo.addItem("Mujer");
		ComboBoxSexo.addItem("Hombre");
		ComboBoxSexo.addItem("No binario");
		ComboBoxSexo.setBounds(106, 123, 141, 22);
		panel.add(ComboBoxSexo);

		JLabel lblOcupacion = new JLabel("Ocupacion:");
		lblOcupacion.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblOcupacion.setBounds(10, 153, 90, 15);
		panel.add(lblOcupacion);

		TxtOcupacion = new JTextField();
		TxtOcupacion.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtOcupacion.setBounds(106, 150, 141, 20);
		panel.add(TxtOcupacion);
		TxtOcupacion.setColumns(10);

		JLabel lblGradodeestudios = new JLabel("Grado De Estudios");
		lblGradodeestudios.setToolTipText("");
		lblGradodeestudios.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblGradodeestudios.setBounds(10, 179, 154, 15);
		panel.add(lblGradodeestudios);

		comboMotivo = new JComboBox<String>();
		comboMotivo.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		comboMotivo.addItem("");
		comboMotivo.addItem("Primaria");
		comboMotivo.addItem("Secundaria");
		comboMotivo.addItem("Preparatoria");
		comboMotivo.addItem("Preparatoria Trunca");
		comboMotivo.addItem("Licenciatura");
		comboMotivo.addItem("Licenciatura Trunca");
		comboMotivo.addItem("Maestria");
		comboMotivo.addItem("Doctorado");
		comboMotivo.setBounds(174, 178, 143, 22);
		panel.add(comboMotivo);

		JLabel lblDomicilio = new JLabel("Domicilio:");
		lblDomicilio.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblDomicilio.setBounds(10, 204, 80, 14);
		panel.add(lblDomicilio);

		TxtDomicilio = new JTextField();
		TxtDomicilio.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtDomicilio.setBounds(106, 202, 141, 17);
		panel.add(TxtDomicilio);
		TxtDomicilio.setColumns(10);

		JLabel lblEstadocivil = new JLabel("Estado Civil:");
		lblEstadocivil.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblEstadocivil.setBounds(10, 238, 106, 14);
		panel.add(lblEstadocivil);

		TxtEstadoCivil = new JTextField();
		TxtEstadoCivil.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtEstadoCivil.setBounds(106, 238, 141, 20);
		panel.add(TxtEstadoCivil);
		TxtEstadoCivil.setColumns(10);

		JLabel lblMotivodeconsulta = new JLabel("Motivo  De Consulta:");
		lblMotivodeconsulta.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblMotivodeconsulta.setBounds(10, 275, 180, 14);
		panel.add(lblMotivodeconsulta);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 300, 237, 105);
		panel.add(scrollPane);

		textMotivo = new JTextArea();
		textMotivo.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		scrollPane.setViewportView(textMotivo);
		textMotivo.setLineWrap(true);
		textMotivo.setWrapStyleWord(true);

		JLabel lblMes = new JLabel("Mes:");
		lblMes.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblMes.setBounds(257, 75, 60, 14);
		panel.add(lblMes);

		TxtMes = new JTextField();
		TxtMes.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtMes.setBounds(323, 72, 60, 20);
		panel.add(TxtMes);
		TxtMes.setColumns(10);

		JLabel lblAnio = new JLabel("Año:");
		lblAnio.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblAnio.setBounds(257, 101, 60, 14);
		panel.add(lblAnio);

		TxtAnio = new JTextField();
		TxtAnio.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		TxtAnio.setBounds(323, 98, 60, 20);
		panel.add(TxtAnio);
		TxtAnio.setColumns(10);

		JButton btnguardarpaciente = new JButton("Guardar paciente");
		btnguardarpaciente.setBackground(new Color(204, 204, 255));
		btnguardarpaciente.addActionListener(new ActionListener() {
			// Funcion que llama al guardado cuando se presiona el boton.
			public void actionPerformed(ActionEvent e) {
				guardarPaciente();
			}
		});
		btnguardarpaciente.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnguardarpaciente.setBounds(10, 416, 136, 23);
		panel.add(btnguardarpaciente);

		JButton btnMostrarTodos = new JButton("Mostrar todos");
		btnMostrarTodos.setBackground(new Color(204, 204, 255));
		btnMostrarTodos.addActionListener(new ActionListener() {
			// Funcion que muestra todos los expedientes cuando se presiona el boton.
			public void actionPerformed(ActionEvent e) {
				mostrarTodosLosExpedientes();
			}
		});
		btnMostrarTodos.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		btnMostrarTodos.setBounds(156, 416, 136, 23);
		panel.add(btnMostrarTodos);

		JLabel lblImagen = new JLabel("");
		lblImagen.setIcon(new ImageIcon(InterfazDeRegistro.class.getResource("/Ventanas/Psicologia.png")));
		lblImagen.setBounds(475, 0, 180, 168);
		panel.add(lblImagen);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 655, 21);
		panel_1.setOpaque(false);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 204, 230));
		menuBar.setToolTipText("");
		menuBar.setBounds(0, 0, 655, 22);
		panel_1.add(menuBar);

		JMenu mnNewMenuMostrar = new JMenu("Mostrar");
		mnNewMenuMostrar.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mnNewMenuMostrar.setBackground(new Color(0, 128, 255));
		menuBar.add(mnNewMenuMostrar);

		JMenuItem mntmNewMenuItemMes = new JMenuItem("Mes");
		mntmNewMenuItemMes.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mntmNewMenuItemMes.setHorizontalAlignment(SwingConstants.CENTER);
		mntmNewMenuItemMes.setBackground(new Color(0, 128, 255));
		mntmNewMenuItemMes.addActionListener(new ActionListener() {
			// Funcion que muestra expedientes por mes desde el menu.
			public void actionPerformed(ActionEvent e) {
				mostrarPorMes();
			}
		});
		mnNewMenuMostrar.add(mntmNewMenuItemMes);

		JMenuItem mntmNewMenuItemAnio = new JMenuItem("Año");
		mntmNewMenuItemAnio.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mntmNewMenuItemAnio.setHorizontalAlignment(SwingConstants.CENTER);
		mntmNewMenuItemAnio.addActionListener(new ActionListener() {
			// Funcion que muestra expedientes por año desde el menu.
			public void actionPerformed(ActionEvent e) {
				mostrarPorAnio();
			}
		});
		mnNewMenuMostrar.add(mntmNewMenuItemAnio);

		JMenu mnNewMenuFiltrarpor = new JMenu("Filtrar por");
		mnNewMenuFiltrarpor.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		menuBar.add(mnNewMenuFiltrarpor);

		JMenuItem mntmNewMenuItemEdad = new JMenuItem("Edad");
		mntmNewMenuItemEdad.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mntmNewMenuItemEdad.addActionListener(new ActionListener() {
			// Funcion que filtra expedientes por edad desde el menu.
			public void actionPerformed(ActionEvent e) {
				filtrarPorEdad();
			}
		});
		mnNewMenuFiltrarpor.add(mntmNewMenuItemEdad);

		JMenuItem mntmNewMenuItemSexo = new JMenuItem("Sexo");
		mntmNewMenuItemSexo.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mntmNewMenuItemSexo.addActionListener(new ActionListener() {
			// Funcion que filtra expedientes por sexo desde el menu.
			public void actionPerformed(ActionEvent e) {
				filtrarPorSexo();
			}
		});
		mnNewMenuFiltrarpor.add(mntmNewMenuItemSexo);

		JMenu mnExpediente = new JMenu("Expediente");
		mnExpediente.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		menuBar.add(mnExpediente);

		JMenuItem mntmModificar = new JMenuItem("Modificar");
		mntmModificar.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mntmModificar.addActionListener(new ActionListener() {
			// Funcion que abre la modificacion de expediente desde el menu.
			public void actionPerformed(ActionEvent e) {
				modificarExpediente();
			}
		});
		mnExpediente.add(mntmModificar);

		JMenuItem mntmEliminar = new JMenuItem("Eliminar");
		mntmEliminar.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		mntmEliminar.addActionListener(new ActionListener() {
			// Funcion que abre la eliminacion de expediente desde el menu.
			public void actionPerformed(ActionEvent e) {
				eliminarExpediente();
			}
		});
		mnExpediente.add(mntmEliminar);
		
		JLabel Fondo = new JLabel("");
		Fondo.addComponentListener(new ComponentAdapter() {
			
			public void componentHidden(ComponentEvent e) {
			}
		});
		Fondo.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
			}
			public void ancestorMoved(AncestorEvent event) {
			}
			public void ancestorRemoved(AncestorEvent event) {
			}
		});
		Fondo.setIcon(new ImageIcon(InterfazDeRegistro.class.getResource("/Ventanas/FondoFlores.png")));
		Fondo.setBounds(0, 0, 655, 494);
		contentPane.add(Fondo);
	}

	// Funcion que toma los datos de la ventana y guarda un objeto Paciente.
	private void guardarPaciente() {
		Paciente pacienteNuevo = crearPacienteDesdeFormulario();

		if (datosCompletos(pacienteNuevo) == false) {
			JOptionPane.showMessageDialog(null, "Debe completar todos los datos.");
		} else {
			ArchivoDeGuardar gestor = new ArchivoDeGuardar();
			String mensaje = gestor.guardarPaciente(pacienteNuevo);
			JOptionPane.showMessageDialog(null, mensaje);
			if (mensaje.startsWith("Paciente guardado")) {
				limpiar();
			}
		}
	}

	// Funcion que convierte los datos escritos en la ventana en un objeto Paciente.
	private Paciente crearPacienteDesdeFormulario() {
		String nombre = TxtNombre.getText().trim();
		String edad = TxtEdad.getText().trim();
		String sexo = ComboBoxSexo.getSelectedItem().toString();
		String ocupacion = TxtOcupacion.getText().trim();
		String grado = comboMotivo.getSelectedItem().toString();
		String domicilio = TxtDomicilio.getText().trim();
		String estadoCivil = TxtEstadoCivil.getText().trim();
		String motivo = textMotivo.getText().trim();
		String mes = TxtMes.getText().trim();
		String anio = TxtAnio.getText().trim();

		return new Paciente("", nombre, edad, sexo, ocupacion, grado, domicilio, estadoCivil, motivo, mes, anio);
	}

	// Funcion que verifica que el objeto Paciente tenga todos sus datos.
	private boolean datosCompletos(Paciente paciente) {
		return !paciente.getNombre().equals("") && !paciente.getEdad().equals("") && !paciente.getSexo().equals("")
				&& !paciente.getOcupacion().equals("") && !paciente.getGradoEstudios().equals("")
				&& !paciente.getDomicilio().equals("") && !paciente.getEstadoCivil().equals("")
				&& !paciente.getMotivoConsulta().equals("") && !paciente.getMes().equals("")
				&& !paciente.getAnio().equals("");
	}

	// Funcion que solicita una edad y muestra los expedientes encontrados.
	private void filtrarPorEdad() {
		String edad = JOptionPane.showInputDialog(null, "Escribe la edad:");
		if (edad != null) {
			ArchivoDeGuardar gestor = new ArchivoDeGuardar();
			JOptionPane.showMessageDialog(null, gestor.filtrarPorEdad(edad.trim()));
		}
	}

	// Funcion que solicita un sexo y muestra los expedientes encontrados.
	private void filtrarPorSexo() {
		String sexo = JOptionPane.showInputDialog(null, "Escribe el sexo:");
		if (sexo != null) {
			ArchivoDeGuardar gestor = new ArchivoDeGuardar();
			JOptionPane.showMessageDialog(null, gestor.filtrarPorSexo(sexo.trim()));
		}
	}

	// Funcion que solicita un mes y muestra los expedientes encontrados.
	private void mostrarPorMes() {
		String mes = JOptionPane.showInputDialog(null, "Escribe el mes:");
		if (mes != null) {
			ArchivoDeGuardar gestor = new ArchivoDeGuardar();
			JOptionPane.showMessageDialog(null, gestor.mostrarPorMes(mes.trim()));
		}
	}

	// Funcion que solicita un año y muestra los expedientes encontrados.
	private void mostrarPorAnio() {
		String anio = JOptionPane.showInputDialog(null, "Escribe el año:");
		if (anio != null) {
			ArchivoDeGuardar gestor = new ArchivoDeGuardar();
			JOptionPane.showMessageDialog(null, gestor.mostrarPorAnio(anio.trim()));
		}
	}

	// Funcion que muestra todos los expedientes guardados en el archivo.
	private void mostrarTodosLosExpedientes() {
		ArchivoDeGuardar gestor = new ArchivoDeGuardar();
		JOptionPane.showMessageDialog(null, gestor.mostrarTodos());
	}

	// Funcion que modifica un expediente buscando primero por folio.
	private void modificarExpediente() {
		String folio = JOptionPane.showInputDialog(null, "Escribe el folio del expediente:");
		if (folio != null) {
			ArchivoDeGuardar gestor = new ArchivoDeGuardar();
			Paciente pacienteActual = gestor.buscarPorFolio(folio.trim());

			if (pacienteActual == null) {
				JOptionPane.showMessageDialog(null, "No se encontro un expediente con ese folio.");
				return;
			}

			Paciente pacienteModificado = pedirDatosModificados(pacienteActual);
			if (pacienteModificado == null) {
				JOptionPane.showMessageDialog(null, "Modificacion cancelada.");
				return;
			}

			if (datosCompletos(pacienteModificado) == false) {
				JOptionPane.showMessageDialog(null, "No se permiten datos vacios.");
				return;
			}

			JOptionPane.showMessageDialog(null, gestor.modificarPaciente(pacienteModificado));
		}
	}

	// Funcion que pide los nuevos datos del expediente y conserva el mismo folio.
	private Paciente pedirDatosModificados(Paciente pacienteActual) {
		String nombre = pedirValor("Nombre:", pacienteActual.getNombre());
		if (nombre == null) {
			return null;
		}
		String edad = pedirValor("Edad:", pacienteActual.getEdad());
		if (edad == null) {
			return null;
		}
		String sexo = pedirValor("Sexo:", pacienteActual.getSexo());
		if (sexo == null) {
			return null;
		}
		String ocupacion = pedirValor("Ocupacion:", pacienteActual.getOcupacion());
		if (ocupacion == null) {
			return null;
		}
		String grado = pedirValor("Grado de estudios:", pacienteActual.getGradoEstudios());
		if (grado == null) {
			return null;
		}
		String domicilio = pedirValor("Domicilio:", pacienteActual.getDomicilio());
		if (domicilio == null) {
			return null;
		}
		String estadoCivil = pedirValor("Estado civil:", pacienteActual.getEstadoCivil());
		if (estadoCivil == null) {
			return null;
		}
		String motivo = pedirValor("Motivo de consulta:", pacienteActual.getMotivoConsulta());
		if (motivo == null) {
			return null;
		}
		String mes = pedirValor("Mes:", pacienteActual.getMes());
		if (mes == null) {
			return null;
		}
		String anio = pedirValor("Año:", pacienteActual.getAnio());
		if (anio == null) {
			return null;
		}

		return new Paciente(pacienteActual.getFolio(), nombre, edad, sexo, ocupacion, grado, domicilio, estadoCivil,
				motivo, mes, anio);
	}

	// Funcion que muestra una ventana para editar un dato y devuelve el texto escrito.
	private String pedirValor(String mensaje, String valorActual) {
		String valor = JOptionPane.showInputDialog(null, mensaje, valorActual);
		if (valor == null) {
			return null;
		}
		return valor.trim();
	}

	// Funcion que elimina un expediente despues de confirmar el folio.
	private void eliminarExpediente() {
		String folio = JOptionPane.showInputDialog(null, "Escribe el folio del expediente:");
		if (folio != null) {
			int respuesta = JOptionPane.showConfirmDialog(null, "Desea eliminar el expediente " + folio.trim() + "?",
					"Confirmar eliminacion", JOptionPane.YES_NO_OPTION);
			if (respuesta == JOptionPane.YES_OPTION) {
				ArchivoDeGuardar gestor = new ArchivoDeGuardar();
				JOptionPane.showMessageDialog(null, gestor.eliminarPaciente(folio.trim()));
			}
		}
	}

	// Funcion que limpia los campos de la ventana despues de guardar.
	private void limpiar() {
		TxtNombre.setText("");
		TxtEdad.setText("");
		ComboBoxSexo.setSelectedIndex(0);
		TxtOcupacion.setText("");
		comboMotivo.setSelectedIndex(0);
		TxtDomicilio.setText("");
		TxtEstadoCivil.setText("");
		textMotivo.setText("");
		TxtMes.setText("");
		TxtAnio.setText("");
	}
}
